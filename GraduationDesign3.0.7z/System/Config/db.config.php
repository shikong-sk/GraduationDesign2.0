<?php
	$db_ip = "127.0.0.1";
	$db_port = "3306";
	$db_user = "root";
	$db_password = "";
	$db_name = "twxb";
	$db_table_prefix = "tw";
